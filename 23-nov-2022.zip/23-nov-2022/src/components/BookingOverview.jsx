
function BookingOverview () {
    return (
        <table className="timeTable">
             <tr>
                <td className="availiable">
                    
                    
                </td>
                <td className="timeOverview">firebase time</td>
            </tr>
            <tr>
                <td className="availiable">firebase availiability</td>
                <td className="timeOverview">firebase time</td>
            </tr>
            <tr>
                <td className="availiable">firebase availiability</td>
                <td className="timeOverview">firebase time</td>
            </tr>
            <tr>
                <td className="availiable">firebase availiability</td>
                <td className="timeOverview">firebase time</td>
            </tr>
        </table>
    );

}
export default BookingOverview;