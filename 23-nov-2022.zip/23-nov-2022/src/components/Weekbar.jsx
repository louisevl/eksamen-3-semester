import pil_venstre from "./../pil_venstre.png"
import pil_hojre from "./../pil_hojre.png"

import { useEffect, useState } from "react";
import Modal from "react-modal";
import BookingForm from "./BookingForm.jsx";


function Weekbar() {
    const [modalIsOpen, setModalIsOpen] = useState(false);

  const openModal = () => {
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };


    return (
        <div className="bar">
        <img id="pil_venstre" src={pil_venstre} />
        <button id="uge">Uge 48</button>
        <button id="mandag">Mandag</button>
        <button id="tirsdag">Tirsdag</button>
        <button id="onsdag">Onsdag</button>
        <button id="torsdag">Torsdag</button>
        <button id="fredag">Fredag</button>
        <button id="uge">Uge 50</button>
        <img id="pil_hojre" src={pil_hojre} />
        </div>
    );
  }
  
  export default Weekbar;
  



