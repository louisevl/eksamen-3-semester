function Name({name}) {
    return (
        <p>
            {name}
        </p>
    )
}

export default Name;