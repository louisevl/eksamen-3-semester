import overview1 from "./../B-Overview-et.png";

function BookingOverview () {
    return (
        // SKAL BRUGES TIL EKSAMEN
        //<table className="timeTable">
             //<tr>
                //<td className="availiable">
                    
                    
                //</td>
               // <td className="timeOverview">firebase time</td>
            //</tr>
            //<tr>
            //    <td className="availiable">firebase availiability</td>
            //    <td className="timeOverview">firebase time</td>
           // </tr>
            //<tr>
            //    <td className="availiable">firebase availiability</td>
            //    <td className="timeOverview">firebase time</td>
           // </tr>
            //<tr>
            //    <td className="availiable">firebase availiability</td>
            //    <td className="timeOverview">firebase time</td>
           // </tr>
       // </table>

    <div className="">
       <img src={overview1} id="imgoverview" alt="" />
    </div>
    );

}
export default BookingOverview;